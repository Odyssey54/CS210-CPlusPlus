/*
 * Whale.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef HEADER_WHALE_H_
#define HEADER_WHALE_H_

#include <string>
#include "Common.h"
#include "Mammal.h"

class Whale : public Mammal {
	public:
		string GetSubType();
		void Print();
	private:
		string subType = "Whale";
};

#endif /* HEADER_WHALE_H_ */
