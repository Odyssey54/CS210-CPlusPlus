/*
 * AnimalData.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include "Bat.h"
#include "Crocodile.h"
#include "Goose.h"
#include "Pelican.h"
#include "SeaLion.h"
#include "Whale.h"
#include "AnimalData.h"
#include "Oviparous.h"
#include "Mammal.h"
#include "Animal.h"
using namespace std;

void AnimalData::AddAnimalData(Animal* animal) {
	animalVector.push_back(animal);
	++count;
}

void AnimalData::DeleteAnimalData(string trackNum) {
	unsigned int i;
	Animal* tmp = nullptr;
	for(i = 0; i < count; ++i) {
		if(animalVector.at(i)->GetTrackNum() == trackNum) {
			tmp = animalVector.at(i);
			delete tmp;
			animalVector.erase(animalVector.begin() + i);
			--count;
		}
	}
}

void AnimalData::DeleteAnimalData(Animal animal) {
	DeleteAnimalData(animal.GetName());
}

void AnimalData::TruncateData() {
	Animal* tmp = nullptr;
	while(animalVector.size() > 0) {
		tmp = animalVector.at(count-1);
		delete tmp;
		animalVector.erase(animalVector.begin() + count-1);
		--count;
	}
}

Animal* AnimalData::GetAnimalData(string trackNum) {
	Animal* animal = nullptr;
	unsigned int i;
	for(i = 0; i < count; ++i) {
		if(animalVector.at(i)->GetTrackNum() == trackNum) {
			animal = animalVector.at(i);
		}
	}
	return animal;
}

void AnimalData::WriteAnimalDataToFile(string filename) {
	ofstream outFS;			// output stream to write to file

	// open file for writing
	outFS.open(filename);

	if(!outFS.is_open()) {
		cout << "Could not open file.";
	} else {
		// accumulate to stream with a stringstream
		// found the following resource to help redirect all print
		// statements to a stringstream which can be used to
		// write the contents to a file
		// https://stackoverflow.com/questions/5419356/redirect-stdout-stderr-to-a-string
		stringstream buffer;
		// store old buffer for reset
		streambuf * old = cout.rdbuf(buffer.rdbuf());
		for(unsigned int i = 0; i < count; ++i) {
			// reset stringstream
			buffer.str("");
			animalVector.at(i)->Print();
			outFS << buffer.str();
		}
		// reset cout buffer
		cout.rdbuf(old);
		cout << "Save successfully completed." << endl;
		outFS.close();
	}
}

void AnimalData::Print() {
	unsigned int i;

	// print out data
	cout << setw(15) << left << "Track #";
	cout << setw(15) << left << "Name";
	cout << setw(15) << left << "Type";
	cout << setw(15) << left << "Eggs";
	cout << setw(15) << left << "Nurse";
	cout << setw(15) << left << "Sub-type";
	cout << endl;

	for(i = 0; i < count; ++i) {
		animalVector.at(i)->Print();
		cout << endl;
	}
}
