/*
 * Crocodile.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include <iostream>
#include <iomanip>
#include "Crocodile.h"

string Crocodile::GetSubType() {
	return subType;
}

void Crocodile::Print() {
	Animal::Print();
	Oviparous::PrintAnimalType();
	cout << setw(15) << left << subType;
	Oviparous::PrintNumberOfEggs();
	cout << setw(15) << left << '0';
}
