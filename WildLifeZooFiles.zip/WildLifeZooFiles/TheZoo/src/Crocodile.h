/*
 * Crocodile.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef HEADER_CROCODILE_H_
#define HEADER_CROCODILE_H_

#include "Oviparous.h"

class Crocodile : public Oviparous {
	public:
		string GetSubType();
		void Print();
	private:
		string subType = "Crocodile";
};

#endif /* CROCODILE_H_ */
