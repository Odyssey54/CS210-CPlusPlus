/*
 * AnimalResolver.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef ANIMALRESOLVER_H_
#define ANIMALRESOLVER_H_

class AnimalResolver {
public:
	AnimalResolver();
	virtual ~AnimalResolver();
};

#endif /* ANIMALRESOLVER_H_ */
