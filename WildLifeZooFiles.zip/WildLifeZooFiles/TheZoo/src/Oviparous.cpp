/*
 * Oviparous.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include <string>
#include <iostream>
#include <iomanip>
#include "Oviparous.h"

string Oviparous::GetAnimalType() const {
	return animalType;
}

void Oviparous::SetNumberOfEggs(int eggs) {
	this->eggs = eggs;
}

int Oviparous::GetNumberOfEggs() const {
	return eggs;
}

void Oviparous::PrintAnimalType() {
	cout << setw(15) << left << animalType;
}

void Oviparous::PrintNumberOfEggs() {
	cout << setw(15) << left << eggs;
}

void Oviparous::Print() {
	Animal::Print();
	cout << setw(15) << left << "Oviparous";
	cout << setw(15) << left << eggs;
	cout << setw(15) << left << "0";
}
