/*
 * SeaLion.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include <iostream>
#include <iomanip>
#include "SeaLion.h"

string SeaLion::GetSubType() {
	return subType;
}

void SeaLion::Print() {
	Animal::Print();
	Mammal::PrintAnimalType();
	cout << setw(15) << left << subType;
	cout << setw(15) << left << '0';
	Mammal::PrintNurse();
}
