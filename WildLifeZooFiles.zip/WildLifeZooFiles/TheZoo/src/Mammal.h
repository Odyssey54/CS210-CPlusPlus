/*
 * Mammal.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef HEADER_MAMMAL_H_
#define HEADER_MAMMAL_H_

#include "Animal.h"

class Mammal : public Animal {
	public:
		string GetAnimalType() const;
		void SetNurse(int nurse);
		int GetNurse() const;
		void PrintAnimalType();
		void PrintNurse();
		virtual void Print();
	private:
		int nurse;
		string animalType = "Mammal";
};

#endif /* MAMMAL_H_ */
