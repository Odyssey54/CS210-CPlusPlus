/*
 * Common.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include "Common.h"

Common::Common() {
	// TODO Auto-generated constructor stub

}

Common::~Common() {
	// TODO Auto-generated destructor stub
}

