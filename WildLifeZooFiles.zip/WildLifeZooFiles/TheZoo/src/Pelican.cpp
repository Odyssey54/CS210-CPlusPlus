/*
 * Pelican.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include <iostream>
#include <iomanip>
#include "Pelican.h"

string Pelican::GetSubType() {
	return subType;
}

void Pelican::Print() {
	Animal::Print();
	Oviparous::PrintAnimalType();
	cout << setw(15) << left << subType;
	Oviparous::PrintNumberOfEggs();
	cout << setw(15) << left << '0';
}
