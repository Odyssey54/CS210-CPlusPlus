/*
 * Goose.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include <iostream>
#include <iomanip>
#include "Goose.h"

string Goose::GetSubType() {
	return subType;
}

void Goose::Print() {
	Animal::Print();
	Oviparous::PrintAnimalType();
	cout << setw(15) << left << subType;
	Oviparous::PrintNumberOfEggs();
	cout << setw(15) << left << '0';
}
