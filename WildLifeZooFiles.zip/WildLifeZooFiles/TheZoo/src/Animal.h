/*
 * Animal.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef ANIMAL_H_
#define ANIMAL_H_

class Animal {
public:
		string GetName() const;
		string GetTrackNum() const;
		void SetName(string name);
		void SetTrackNum(string trackNum);
		void PrintName();
		void PrintTrackNum();
		virtual void Print();
	private:
		string name;
		string trackNum;
};

#endif /* ANIMAL_H_ */
