/*
 * AnimalData.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef ANIMALDATA_H_
#define ANIMALDATA_H_

#include <string>
#include "Animal.h"
using namespace std;

class AnimalData {
	public:
		void AddAnimalData(Animal* animal);
		void DeleteAnimalData(string trackNum);
		void DeleteAnimalData(Animal animal);
		void TruncateData();
		Animal* GetAnimalData(string trackNum);
		void WriteAnimalDataToFile(string filename);
		void Print();
	private:
		vector<Animal*> animalVector;
		string name = "Animal Data Warehouse";
		unsigned int count = 0;
};

#endif /* ANIMALDATA_H_ */
