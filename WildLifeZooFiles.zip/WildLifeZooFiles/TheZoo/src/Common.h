/*
 * Common.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef HEADER_COMMON_H_
#define HEADER_COMMON_H_

enum animalType { OVIPAROUS, MAMMAL };
enum subType { CROCODILE, BAT, WHALE, GOOSE, PELICAN, SEALION };

#endif /* HEADER_COMMON_H_ */
