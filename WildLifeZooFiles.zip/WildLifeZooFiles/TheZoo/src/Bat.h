/*
 * Bat.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef HEADER_BAT_H_
#define HEADER_BAT_H_

#include <string>
#include "Mammal.h"

class Bat : public Mammal {
	public:
		string GetSubType();
		void Print();
	private:
		string subType = "Bat";
};

#endif /* BAT_H_ */
