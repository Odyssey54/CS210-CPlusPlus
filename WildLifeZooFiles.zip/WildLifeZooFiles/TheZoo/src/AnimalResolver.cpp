/*
 * AnimalResolver.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#include <string>
#include <sstream>
#include <vector>
#include "AnimalData.h"
#include "Bat.h"
#include "Crocodile.h"
#include "Goose.h"
#include "Pelican.h"
#include "SeaLion.h"
#include "Whale.h"
#include "Mammal.h"
#include "Oviparous.h"
#include "Animal.h"
using namespace std;

class AnimalResolver {
	public:
		void resolve(AnimalData* animalData, string track, string name, string animalType, string subType, int eggs, int nurse) {
			if (subType == "Bat" || subType == "bat") {
				Bat* bat = new Bat;
				bat->SetName(name);
				bat->SetTrackNum(track);
				bat->SetNurse(nurse);
				animalData->AddAnimalData(bat);
			}

			if (subType == "Whale" || subType == "whale") {
				Whale* whale = new Whale;
				whale->SetName(name);
				whale->SetTrackNum(track);
				whale->SetNurse(nurse);
				animalData->AddAnimalData(whale);
			}

			if (subType == "SeaLion" || subType == "sealion") {
				SeaLion* sealion = new SeaLion;
				sealion->SetName(name);
				sealion->SetTrackNum(track);
				sealion->SetNurse(nurse);
				animalData->AddAnimalData(sealion);
			}

			if (subType == "Crocodile" || subType == "crocodile") {
				Crocodile* crocodile = new Crocodile;
				crocodile->SetName(name);
				crocodile->SetTrackNum(track);
				crocodile->SetNumberOfEggs(eggs);
				animalData->AddAnimalData(crocodile);
			}

			if (subType == "Goose" || subType == "goose") {
				Goose* goose = new Goose;
				goose->SetName(name);
				goose->SetTrackNum(track);
				goose->SetNumberOfEggs(eggs);
				animalData->AddAnimalData(goose);
			}

			if (subType == "Pelican" || subType == "pelican") {
				Pelican* pelican = new Pelican;
				pelican->SetName(name);
				pelican->SetTrackNum(track);
				pelican->SetNumberOfEggs(eggs);
				animalData->AddAnimalData(pelican);
			}
		}
};
