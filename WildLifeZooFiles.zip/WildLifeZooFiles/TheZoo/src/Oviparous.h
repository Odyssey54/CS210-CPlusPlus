/*
 * Oviparous.h
 *
 *  Created on: Feb 21, 2021
 *      Author: 1796432_snhu
 */

#ifndef HEADER_OVIPAROUS_H_
#define HEADER_OVIPAROUS_H_

#include "Animal.h"
#include "Common.h"

class Oviparous : public Animal {
	public:
		string GetAnimalType() const;
		void SetNumberOfEggs(int eggs);
		int GetNumberOfEggs() const;
		void PrintAnimalType();
		void PrintNumberOfEggs();
		virtual void Print();
	private:
		int eggs;
		string animalType = "Oviparous";
};
#endif /* OVIPAROUS_H_ */
